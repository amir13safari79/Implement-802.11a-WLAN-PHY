% in the name of ALLAH
% check equality of matlab and testbench scrambled frames:
% AmirHossein Safari 97101994

% open and read files:
fileID1 = fopen('matlab_Scrambled_frame.txt','r');
fileID2 = fopen('testbench_Scrambled_frame.txt','r');
matlab_Scrambled_frame = fscanf(fileID1,'%d \n');
testbench_Scrambled_frame = fscanf(fileID2,'%d \n');

% check equality:
check = 1;
for i = 1:1:numel(matlab_Scrambled_frame)
   if(matlab_Scrambled_frame(i) ~= testbench_Scrambled_frame(i))
       check = 0;
   end
end

if(check == 1)
    disp("matlab_Scrambled_frame and testbench_Scrambled_frame are completely equal")
end