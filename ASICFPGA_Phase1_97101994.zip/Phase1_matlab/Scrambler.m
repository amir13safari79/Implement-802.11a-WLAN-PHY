% In the name of ALLAH
% (Scrambler) function for implement Phase1 of ASIC/FPGA project
% AmirHossein Safari 97101994

function [y, initial_seed] = Scrambler(data_frame)
    % initial seed for scrambler function:
    % use randi function for produce seed:
    %initial_seed = de2bi(randi(127), 7);
    %seed = initial_seed;
    initial_seed = [1 0 1 1 1 0 1];
    seed = initial_seed;
    
    % seprate DATA field for scrambling ;
    % according to standard, section 17.3.5 just DATA field should be
    % scramebled.
    DATA = data_frame(37:end);
    scrambled_DATA = zeros(1, numel(DATA)); % initial scrambled_DATA
    
    
    % implement scrambler according to section 17.3.5.4 in standard.
    for i = 1:1:numel(DATA)
        % bit1 is seed[1] xor seed[4]
        bit1 = double(xor(seed(4), seed(7)));
        shifted_seed = zeros(1,7);
        shifted_seed(1) = bit1;
        shifted_seed(2:7) = seed(1:6); % shift seed
        seed = shifted_seed;
        
        % generate scramble bit for DATA bits:
        scrambled_DATA(i) = double(xor(DATA(i), bit1));
    end
    
    
    y = [data_frame(1:36) scrambled_DATA];    

end