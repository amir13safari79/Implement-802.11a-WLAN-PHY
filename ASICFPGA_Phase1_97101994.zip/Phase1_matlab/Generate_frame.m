% In the name of ALLAH
% matlab file for generating data frame for implement scarambling algorithm:
% ASIC/FPGA project ; Phase 1
% AmirHossein Safari 97101994
%% Generating DataFrame:
% Generating Preamble field:
    % I assume Preamble equals to 12'b111111111110.
    % when above sequence appears in frame so we can deduce to new frame
    % starts
    Preamble = [1 1 1 1 1 1 1 1 1 1 1 0];
    
% Generating SIGNAL field consist of:
    %(4 RATE bits, Reserved bit, 12 LENGTH bits, PARITY bit and 6 Tail bits)

    % RARE: assume that RATE is 36Mbit/s with N_DBPS = 144:
    RATE = [1 0 1 1]; % 36Mbit/s map to 4'b1011 according to standard
    N_DBPS = 144;

    % Reserve bit:
    Reserved = 0;

    % LENGTH: according to Annex G2 and Table G1 we assume that:
    % PSDU has 100 octets(800 bits) so Length is 100
    length = 100;
    LENGTH = de2bi(length, 12);
    
    % even Parity bit:
    Parity = 0;
    for i = [RATE, Reserved, LENGTH]
        Parity = mod(i + Parity, 2);
    end

    % Tail bits: Tail bits shall be set to 0 according to standard, section 17.3.4.3
    Tail = zeros(1,6);

    % so SIGNAL field can be produce:
    SIGNAL = [RATE, Reserved, LENGTH, Parity, Tail];

% Generating DATA field consist of:
    % (16 SERVICE bits, PSDU, 6 Tail bits and Pad bits)
    
    % SERVICE: all of 16 SERVICE bits shall be set to 0 according to
    % standard, section 17.3.5.1
    SERVICE = zeros(1,16);
    
    % PSDU: for example we consider 100 octets message that describes in 
    % annex G2(or tabel G1) as our data so create PSDU.
    PSDU = [de2bi(hex2dec('002e000204'),40),...
            de2bi(hex2dec('a637cd0860'),40),...
            de2bi(hex2dec('3c01d62000'),40),...
            de2bi(hex2dec('ad086000f1'),40),...
            de2bi(hex2dec('4a0000af3b'),40),...
            de2bi(hex2dec('62202c796f'),40),...
            de2bi(hex2dec('7468676972'),40),...
            de2bi(hex2dec('7261707320'),40),...
            de2bi(hex2dec('20666f206b'),40),...
            de2bi(hex2dec('6e69766964'),40),...
            de2bi(hex2dec('0a2c797469'),40),...
            de2bi(hex2dec('6867756144'),40),...
            de2bi(hex2dec('6f20726574'),40),...
            de2bi(hex2dec('796c452066'),40),...
            de2bi(hex2dec('2c6d756973'),40),...
            de2bi(hex2dec('657269460a'),40),...
            de2bi(hex2dec('69736e692d'),40),...
            de2bi(hex2dec('7720646572'),40),...
            de2bi(hex2dec('6572742065'),40),...
            de2bi(hex2dec('ed9957da61'),40)];
            
    % Tail bits: Tail bits shall be set to 0 according to standard,
    % section 17.3.5.2
    Tail_d = zeros(1,6);
    
    % Pad bits: first find number of pad bits(N_PAD) according to section 17.3.5.4
    % then set them to 0:
    N_SYM = ceil((16 + 8*length + 6) / N_DBPS); % SYM is DATA symbol;
    N_DATA = N_SYM * N_DBPS;
    N_PAD = N_DATA - (16 + 8*length + 6);
    Pad = zeros(1, N_PAD);
    
    % so DATA field can be produce:
    DATA = [SERVICE, PSDU, Tail_d, Pad];
    
    
% so frame can be produce:
frame = [Preamble, SIGNAL, DATA];

% Scramble frame with Scramble function:
[Scrambled_frame , seed] = Scrambler(frame);

% Descramble Scrambled_frame with Descrambler function:
Descrambled_frame = Descrambler(Scrambled_frame);

% check whether the original data_frame(frame signal) is equal to the
% Descrambled_frame or not:
check = 1;
for i = 1:1:numel(frame)
   if(frame(i) ~= Descrambled_frame(i))
       check = 0;
   end
end

if(check == 1)
    disp("original data_frame(frame signal) and Descrambled_frame are completely equal")
end

% write signals (frame and Scrambled_frame and seed) to textfile for use in 
% testbench to verify verilog code:
fileID1 = fopen('matlab_frame.txt','w');
fileID2 = fopen('matlab_seed.txt','w');
fileID3 = fopen('matlab_Scrambled_frame.txt','w');
fprintf(fileID1,'%d \n',frame);
fprintf(fileID2,'%d\n',seed);
fprintf(fileID3,'%d \n',Scrambled_frame);
