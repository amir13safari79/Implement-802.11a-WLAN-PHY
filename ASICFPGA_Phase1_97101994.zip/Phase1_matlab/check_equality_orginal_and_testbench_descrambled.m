% in the name of ALLAH
% check equality of original and testbench descrambled frames:
% AmirHossein Safari 97101994

% open and read files:
fileID1 = fopen('matlab_frame.txt','r');
fileID2 = fopen('testbench_Descrambled_frame.txt','r');
matlab_frame = fscanf(fileID1,'%d \n');
testbench_Descrambled_frame = fscanf(fileID2,'%d \n');

% check equality:
check = 1;
for i = 1:1:numel(matlab_frame)
   if(matlab_frame(i) ~= testbench_Descrambled_frame(i))
       check = 0;
   end
end

if(check == 1)
    disp("original_frame and testbench_Descrambled_frame are completely equal")
end