% In the name of ALLAH
% (Descrambler) function for implement Phase1 of ASIC/FPGA project
% AmirHossein Safari 97101994

function y = Descrambler(data_frame)
    % first of all seprate Scrambled DATA field from data_fram
    % according to standard, section 17.3.5 just DATA field should be 
    % Scramble and Descramble.
    Scrambled_DATA = data_frame(37:end);
    Descrambled_DATA = zeros(1, numel(Scrambled_DATA)); % initial descrambled_DATA
    
    % then find seed that Scrambled_DATA scrambled with.
    % first 7 bit of Scrambled_DATA(first 7 bit of SERVICE field):
    seed = zeros(1,7);
    seed(1) = double(xor(Scrambled_DATA(3), Scrambled_DATA(7)));
    seed(2) = double(xor(Scrambled_DATA(2), Scrambled_DATA(6)));
    seed(3) = double(xor(Scrambled_DATA(1), Scrambled_DATA(5)));
    seed(4) = double(xor(seed(1), Scrambled_DATA(4)));
    seed(5) = double(xor(seed(2), Scrambled_DATA(3)));
    seed(6) = double(xor(seed(3), Scrambled_DATA(2)));
    seed(7) = double(xor(seed(4), Scrambled_DATA(1)));
    
    % implement Descrambler like Scramble according to section 17.3.5.4 in standard.
    for i = 1:1:numel(Scrambled_DATA)
        % bit1 is seed[1] xor seed[4]
        bit1 = double(xor(seed(4), seed(7)));
        shifted_seed = zeros(1,7);
        shifted_seed(1) = bit1;
        shifted_seed(2:7) = seed(1:6); % shift seed
        seed = shifted_seed;
        
        % generate scramble bit for DATA bits:
        Descrambled_DATA(i) = double(xor(Scrambled_DATA(i), bit1));
    end

    y = [data_frame(1:36), Descrambled_DATA];

end