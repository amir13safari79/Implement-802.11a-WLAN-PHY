% In the name of ALLAH
% (Deinterleaver) function for implement Phase3 of ASIC/FPGA project
% this Deinterleaver use for Deinterleaving DATA field of interleaved frames with :
% Data rate = 24, Coding rate = 1/2, N_BPSC = 4, N_CBPS = 192, N_DBPS = 96
% AmirHossein Safari 97101994

function [deinterleaved_frame, x, y] = Deinterleaver(received_frame)
    % seprate first 12 bit of received_frame that are Preamble:
    Preamble = received_frame(1:12);
    interleaved_frame = received_frame(13:end);
    
    % seprate first 48 bit of interleaved_frame ...
    % These 48 bits are interleaved in the SIGNAL field.
    interleaved_signal = interleaved_frame(1:48);
    
    % also seprate other bits as interleaved_DATA:
    interleaved_data = interleaved_frame(49:end);
    
    % Deinterleaving interleaved_signal and interleaved_data:
        % Deinterleaving interleaved_siganl:
            % according to section G.4.3 Deinterleave encoded_signal with ...
            % N_BPSC = 1 and N_CBPS = 48:
            N_BPSC = 1;
            N_CBPS = 48;
            s = max([N_BPSC/2 , 1]);
            deinterleaved_signal = zeros(1,48);
        
            % produce j index:
            j = 0:1:N_CBPS - 1;
        
            % produce i index:
            i = s*floor(j/s) + mod((j + floor(16*j/N_CBPS)),s);
            

            % produce k index:
            k = 16*i - (N_CBPS-1)*floor(16*i/N_CBPS);
            
            % add 1 to k and j to observe matlab indexing:
            k = k + 1;
            j = j + 1;
            

            % produce deinterleaved_signal
            deinterleaved_signal(k) = interleaved_signal(j);
            
         % Interleaving encoded_data:
            % according to header of this file Interleave encoded_data with ...
            % N_BPSC = 4 and N_CBPS = 192:
            N_BPSC = 4;
            N_CBPS = 192;
            s = max([N_BPSC/2 , 1]);
            symbols_number = numel(interleaved_data) / N_CBPS;
            deinterleaved_data = zeros(1,numel(interleaved_data));
        
            % produce j index:
            j = 0:1:N_CBPS - 1;
        
            % produce i index:
            i = s*floor(j/s) + mod((j + floor(16*j/N_CBPS)),s);
            

            % produce k index:
            k = 16*i - (N_CBPS-1)*floor(16*i/N_CBPS);
            
            % add 1 to k and j to observe matlab indexing:
            k = k + 1;
            j = j + 1;
            
            
            % produce interleaved_data
            for n = 0:1:symbols_number - 1
                deinterleaved_data(k + n*N_CBPS) = interleaved_data(j + n*N_CBPS);
            end
    
    % produce Deinterleaved_frame:
    deinterleaved_frame = [deinterleaved_signal deinterleaved_data];
    

end