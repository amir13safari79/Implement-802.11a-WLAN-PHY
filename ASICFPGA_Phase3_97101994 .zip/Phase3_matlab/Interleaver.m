% In the name of ALLAH
% (Interleaver) function for implement Phase3 of ASIC/FPGA project
% this Interleaver use for Interleaving DATA field of encoded frames with :
% Data rate = 24, Coding rate = 1/2, N_BPSC = 4, N_CBPS = 192, N_DBPS = 96
% AmirHossein Safari 97101994

function interleaver_output_frame = Interleaver(data_frame)
    % seprate first 48 bit of encoded data_frame ...
    % These 48 bits are encoded in the SIGNAL field.
    encoded_signal = data_frame(1:48);
    
    % also seprate other bits as encoded_DATA:
    encoded_data = data_frame(49:end);
    
    % Interleaving encoded_signal and encoded_data:
        % Interleaving encoded_siganl:
            % according to section G.4.3 Interleave encoded_signal with ...
            % N_BPSC = 1 and N_CBPS = 48
            N_BPSC = 1;
            N_CBPS = 48;
            s = max([N_BPSC/2 , 1]);
            interleaved_signal = zeros(1,48);
        
            % produce k index:
            k = 0:1:N_CBPS - 1;
        
            % produce i index:
            i = (N_CBPS/16)*mod(k,16) + floor(k/16);

            % produce j index:
            j = s*floor(i/s) + mod((i + N_CBPS - floor(16*i/N_CBPS)),s);
            
            % add 1 to k and j to observe matlab indexing:
            k = k + 1;
            j = j + 1;
            

            % produce interleaved_signal
            interleaved_signal(j) = encoded_signal(k);
            
         % Interleaving encoded_data:
            % according to header of this file Interleave encoded_data with ...
            % N_BPSC = 4 and N_CBPS = 192:
            N_BPSC = 4;
            N_CBPS = 192;
            s = max([N_BPSC/2 , 1]);
            symbols_number = numel(encoded_data) / N_CBPS;
            interleaved_data = zeros(1,numel(encoded_data));
        
            % produce k index:
            k = 0:1:N_CBPS - 1;
     
            % produce i index:
            i = (N_CBPS/16)*mod(k,16) + floor(k/16);
        
            % produce j index:
            j = s*floor(i/s) + mod((i + N_CBPS - floor(16*i/N_CBPS)),s); 
            
            % add 1 to k and j to observe matlab indexing:
            k = k + 1;
            j = j + 1;
            
            
            % produce interleaved_data
            for n = 0:1:symbols_number - 1
                interleaved_data(j + n*N_CBPS) = encoded_data(k + n*N_CBPS);
            end
    
    % produce Interleaved_frame and add Preamble to this:
    interleaved_frame = [interleaved_signal interleaved_data];
    Preamble = [1 1 1 1 1 1 1 1 1 1 1 0];
    interleaver_output_frame = [Preamble interleaved_frame];


end
