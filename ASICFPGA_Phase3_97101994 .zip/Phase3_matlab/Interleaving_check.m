% In the name of ALLAH
% matlab file to check the correct operation of the Interleaver function.
% ASIC/FPGA project ; Phase 3
% AmirHossein Safari 97101994
%% Import encoded data frame that obtained with convolutional encoder:
    fileID1 = fopen('matlab_encoded_frame.txt','r');
    encoded_frame = fscanf(fileID1,'%d \n');

    % Interleaving encoded_frame with Interleaver function:
    matlab_interleaved_frame = Interleaver(encoded_frame);

    % Deinterleaving interleaver_output_frame:
    matlab_deinterleaved_frame = Deinterleaver(matlab_interleaved_frame);

    % checking equlity of encoded_frame and deinterleaved_frame:
    check = 1;
    for i = 1:1:numel(encoded_frame)
        if(encoded_frame(i) ~= matlab_deinterleaved_frame(i))
            check = 0;
        end
    end

    if(check == 1)
        disp("encoded_frame and matlab_deinterleaved_frame are completely equal")
    end
    fprintf("\n");
    
    
% checking equlity of matlab_interleaved_frame and testbench_interleaved_frame:
    fileID2 = fopen('testbench_interleaved_frame.txt','r');
    testbench_interleaved_frame = fscanf(fileID2,'%d \n');
    
    % Because we set the output bits of the interleaver module to zero ...
    % and the preamble starts at the 181st bit, the first 180 bits are invalid ...
    % and we delete them.
    testbench_interleaved_frame = testbench_interleaved_frame(181:end);
    
    check1 = 1;
    for i = 1:1:numel(encoded_frame)
        if(testbench_interleaved_frame(i) ~= matlab_interleaved_frame(i))
            check1 = 0;
        end
    end

    if(check1 == 1)
        disp("testbench_interleaved_frame and matlab_interleaved_frame are completely equal")
    end
    fprintf("\n");
    
% checking equlity of encoded_frame and testbench_deinterleaved_frame:
    fileID3 = fopen('testbench_deinterleaved_frame.txt','r');
    testbench_deinterleaved_frame = fscanf(fileID3,'%d \n');
    
    % Because we have 385 clock latency so delete first 385 bits:
    testbench_deinterleaved_frame = testbench_deinterleaved_frame(193:1968);
    
    error_bits = [];
    for i = 1:1:numel(encoded_frame)
        if(encoded_frame(i) ~= testbench_deinterleaved_frame(i))
            check2 = 0;
            error_bits = [error_bits i];
        end
    end

    if(check2 == 1)
        disp("matlab_encoded_frame and testbench_deinterleaved_frame are completely equal")
    else
        disp("matlab_encoded_frame and testbench_deinterleaved_frame are not completely equal");
        disp("number of different bits are:")
        disp(numel(error_bits))
    end
    fprintf("\n");
    
    








