% In the name of ALLAH
% (Viterbi decoder) function for implement Phase2 of ASIC/FPGA project
% AmirHossein Safari 97101994

function [decoded_frame, trellis, states] = Viterbi_tmp(encoded_frame)
    
    % First of all, we calculate that for an current state, 
    % if any of the inputs are zero or one, what is the output and next state?
    states = zeros(64, 4); % in the states array for row = i ...
                           % assume that current state = i so ...
                           % states(i,1) indicate output if input = 0
                           % states(i,2) indicate next_state if input = 0
                           % states(i,3) indicate output if input = 1
                           % states(i,4) indicate next_state if input = 1
    
    for i = 0:1:63
        current_state = de2bi(i,6);
        
        % find output and next_state if input = 0 and 1:
        [output_a_0, output_b_0, next_state_0] = find_outputs(current_state, 0);
        [output_a_1, output_b_1, next_state_1] = find_outputs(current_state, 1);
        
        % merge output_a and output_b and convert to decimal:
        output_0 = bi2de([output_a_0, output_b_0]);
        output_1 = bi2de([output_a_1, output_b_1]);
        
        % convert next_state_0 and next_state_1 to decimal:
        next_state_0 = bi2de(next_state_0);
        next_state_1 = bi2de(next_state_1);
        
        % insert valuse in states array:
        states(i + 1,:) = [output_0, next_state_0, output_1, next_state_1];
    end
    
    % now is time to build and fill trellis diagram(array):
    columns_number = 1 + numel(encoded_frame)/2;
    % in the trellis array for row = i and each column j ...
    % assume that current state = i so ...
    % trellis(i,j,1) indicate output if input = 0
    
    % trellis(i,j,2) indicate next_state if input = 0
    
    % trellis(i,j,3) indicate output if input = 1
    
    % trellis(i,j,4) indicate next_state if input = 1
    
    % trellis(i,j,5) indicate The cost that leads us to this element for
    % input = 0 and trellis(i,j,6) shows it's predcessor state
    
    % trellis(i,j,7) indicate The cost that leads us to this element for
    % input = 1 and trellis(i,j,8) shows it's predcessor state
    
    % trellis(i,j,9) indicate The min(trellis(i,j,5) and trellis(i,j,6))
    
    % trellis(i,j,10) indicate input that leads us to this element and makes
    % trellis(i,j,11)(min_cost) element
    trellis = zeros(64, columns_number, 12); 
                      
    % Fill in 4 elements out of 9 elements for the third dimension for all rows and columns in trellis
    % according to previous part:
    for i = 1:1:64
        if(i ~= 1)  % for intital cost of column1
            trellis(i,1,9) = 500;
        end
        for j = 1:1:columns_number
            trellis(i,j,1:4) = states(i,:);
            trellis(i,j,12) = 0;
        end
    end
    
    % update trellis with dynamic programmnig:
    for j = 1:1:numel(encoded_frame)/2
        for i = 1:1:64
            % now we are in current_state i and check for ...
            % encoded_frame(2*j-1) encoded_frame(2*j) bits in column j:
            encoded_bits = [encoded_frame(2*j-1) encoded_frame(2*j)];
            
            % find hamming distance if input was 0 and update next column:
            outputs_0 = de2bi(trellis(i,j,1),2);
            hamming_dist_0 = 0;
            for l = 1:1:2
                if(encoded_bits(l) ~= outputs_0(l))
                    hamming_dist_0 = hamming_dist_0 + 1;
                end
            end
            
            min_cost = trellis(i,j,9);
            next_state_0 = trellis(i,j,2);
            if(trellis(next_state_0 + 1, j + 1, 12) == 0)
                trellis(next_state_0 + 1, j + 1, 5) = min_cost + hamming_dist_0;
                trellis(next_state_0 + 1, j + 1, 6) = i - 1; % i-1 is current state
                trellis(next_state_0 + 1, j + 1, 12) = 1;
                trellis(next_state_0 + 1, j + 1, 10) = 0;
            else
                trellis(next_state_0 + 1, j + 1, 7) = min_cost + hamming_dist_0;
                trellis(next_state_0 + 1, j + 1, 8) = i - 1; % i-1 is current state
            end
            
            % find hamming distance if input was 1 and update next column:
            outputs_1 = de2bi(trellis(i,j,3),2);
            hamming_dist_1 = 0;
            for l = 1:1:2
                if(encoded_bits(l) ~= outputs_1(l))
                    hamming_dist_1 = hamming_dist_1 + 1;
                end
            end
            
            next_state_1 = trellis(i,j,4);
            if(trellis(next_state_1 + 1, j + 1, 12) == 0)
                trellis(next_state_1 + 1, j + 1, 5) = min_cost + hamming_dist_1;
                trellis(next_state_1 + 1, j + 1, 6) = i - 1; % i-1 is current state
                trellis(next_state_1 + 1, j + 1, 12) = 1;
                trellis(next_state_1 + 1, j + 1, 10) = 1;
            else
                trellis(next_state_1 + 1, j + 1, 7) = min_cost + hamming_dist_1;
                trellis(next_state_1 + 1, j + 1, 8) = i - 1; % i-1 is current state
            end
        end
        
        % find min_cost and predcessors:
        for i = 1:1:64
            cost_0 = trellis(i,j+1,5);
            cost_1 = trellis(i,j+1,7);
            if(cost_0 <= cost_1)
                trellis(i,j+1,9) = cost_0;
                trellis(i,j+1,11) = trellis(i,j+1,6);
            else
                trellis(i,j+1,9) = cost_1;
                trellis(i,j+1,11) = trellis(i,j+1,8);
            end
        end
    end
                
    % find decoded frame with backtracking:
    decoded_frame = zeros(1,numel(encoded_frame)/2);
    
    % find first back_state that has the minimum cost:
    back_state = 1;
    for i = 1:1:64
        if(trellis(i,columns_number,9) < trellis(back_state,columns_number,9))
            back_state = i;
        end
    end
    
    for j = columns_number:-1:2
        decoded_frame(j - 1) = trellis(back_state,j,10);
        back_state = trellis(back_state,j,11) + 1;
    end
    
    
        
        
        
end