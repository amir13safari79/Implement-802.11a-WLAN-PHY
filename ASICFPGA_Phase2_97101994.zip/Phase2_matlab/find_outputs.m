% In the name of ALLAH
% (find output_A and output_B and next state for use in (Viterbi_decoder function))
% for implement Phase2 of ASIC/FPGA project
% AmirHossein Safari 97101994

function [output_a, output_b, next_state] = find_outputs(current_state, input)
    next_state = [input, current_state(1:5)];
    
    % produce output_a
    output_a = input; 
    for j = [2 3 5 6]
        output_a = double(xor(output_a, current_state(j)));
    end

    % produce output_b
    output_b = input; 
    for j = [1 2 3 6]
        output_b = double(xor(output_b, current_state(j)));
    end
    
end

