% in the name of ALLAH
% check equality of matlab and testbench encoded frames:
% AmirHossein Safari 97101994

% open and read files:
fileID1 = fopen('matlab_encoded_frame.txt','r');
fileID2 = fopen('testbench_encoded_frame.txt','r');
matlab_encoded_frame = fscanf(fileID1,'%d \n');
testbench_encoded_frame = fscanf(fileID2,'%d \n');

% check equality:
check = 1;
for i = 1:1:numel(matlab_encoded_frame)
   if(matlab_encoded_frame(i) ~= testbench_encoded_frame(i))
       check = 0;
   end
end

if(check == 1)
    disp("matlab_encoded_frame and testbench_encoded_frame are completely equal")
end