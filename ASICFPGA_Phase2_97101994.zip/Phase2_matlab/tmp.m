% In the name of ALLAH
% (Convolutional encoder with rate = 1/2) function for implement Phase2 of ASIC/FPGA project
% AmirHossein Safari 97101994

function [output_data_A, output_data_B] = tmp(data_frame)
%     find data_rate and coding_rate of data_frame:
%     data_rate = data_frame(13:16);
%     
%     for data_rates equals to 6([1 1 0 1]), 12([0 1 0 1] and 24([1 0 0 1])
%     coding rate = 1/2:
%     if((data_rate(1) || data_rate(2) == 1) && ~data_rate(3) && data_rate(4))
%         coding_rate = 1/2;
%     end
%     
%     for data_rates equals to 48([0 0 0 1]) coding rate = 2/3:
%     if(~data_rate(1) && ~data_rate(2) && ~data_rate(3) && data_rate(4))
%         coding_rate = 2/3;
%     end
%     
%     for data_rates equals to 9([1 1 0 1]), 18([0 1 0 1], 36([1 0 0 1])
%     and 54([0 0 1 1]) coding rate = 3/4:
%     if(data_rate(3) && data_rate(4))
%         coding_rate = 3/4;
%     end
    
    
    % seprate DATA field for Convolutional encoding ;
    % according to standard, section 17.3.5.5 and Annex G4.2 DATA field should be
    % encode with coding_rate in the SIGNAL field and SIGNAL field itself
    % should be encode with rate = 1/2:
    % so all bits of data frame should be encoded with rate = 1/2
    %signal = data_frame(1:24);
    %data = data_frame(25:end);
    
    % implement Convolutional_encoder:
    % First of all, we initialize the signal length encoded_data to 2 times the signal length data by -1.
    output_data_A = zeros(1, numel(data_frame));
    output_data_B = zeros(1, numel(data_frame));
    encode_reg = [0 0 0 0 0 0];
    
%     encoding SIGNAL field:
%     for i = 1:1:numel(signal)
%         produce and insert output_a
%         output_a = signal(i); 
%         for j = [2 3 5 6]
%             output_a = double(xor(output_a, encode_reg(j)));
%         end
%         output_data_A(i) = output_a;
%         
%         produce and insert output_b
%         output_b = signal(i); 
%         for j = [1 2 3 6]
%             output_b = double(xor(output_b, encode_reg(j)));
%         end
%         output_data_B(i) = output_b;
%         
%         shift encode_reg:
%         encode_reg = [signal(i) encode_reg(1:5)];
%     end

    % encoding DATA field:
    for i = 1:1:numel(data_frame)
        % produce and insert output_a
        output_a = data_frame(i); 
        for j = [2 3 5 6]
            output_a = double(xor(output_a, encode_reg(j)));
        end
        output_data_A(i) = output_a;
            
        % produce and insert output_b
        output_b = data_frame(i); 
        for j = [1 2 3 6]
            output_b = double(xor(output_b, encode_reg(j)));
        end
        output_data_B(i) = output_b;
    
        % shift encode_reg:
        encode_reg = [data_frame(i) encode_reg(1:5)];
    end
end
